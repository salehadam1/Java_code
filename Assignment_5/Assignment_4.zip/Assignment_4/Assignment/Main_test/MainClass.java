import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MainClass {

    public static void main(String[] args) throws IOException {

        int i = 1;
        int ask;
        Scanner sc = new Scanner(System.in);
        user newuser = new user();
        Vector<user> user1 = new Vector<>();
        Read_File.Read_From_File(user1, args[0]);

        System.out.println("***Chose one of the option**\n1 - To  Display the 10 Largest Earthquakes" +
                "\n2 - To  Display the 10 nearest earthquakes to My location\n" +
                "3 - To Display the 10 Largest Explosions\n" +
                "4 - To Display the 10 Largest Ice Quake\n" +
                "5 - To Display the 10 Largest Quarry Blast\n" +
                "0 - to Exit");
        ask = sc.nextInt();
        while(ask != 0)
        {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("    Mag         Latitude         longitude              Time                      Place                       Type           Distance\n");
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------");
            if(ask == 1)
            {
                List<user> Earthquakes = user1.stream()
                        .filter(e-> e.getType().equalsIgnoreCase("Earthquake"))
                        .sorted(Comparator.comparingDouble(user::getMag).reversed())
                        .limit(10)
                        .collect(Collectors.toList());
                System.out.println(" "+ Earthquakes);
            }
            else if(ask == 2)
            {
                System.out.printf("Nearest earthquakes to my location of Latitude: 53.34350465 and longitude: -8.873374084151076 Galway Ireland\n\n");

                List<user> nearest_earthquakes = user1.stream()
                        .filter(e-> e.getType().equalsIgnoreCase("Earthquake"))
                        .sorted(Comparator.comparingDouble(user::getLocat))
                        .limit(20)
                        .collect(Collectors.toList());
                System.out.println(" "+nearest_earthquakes);
            }
            else if(ask == 3)
            {
                List<user> Explosions = user1.stream()
                        .filter(e-> e.getType().equalsIgnoreCase("Explosion"))
                        .sorted(Comparator.comparingDouble(user::getMag).reversed())
                        .limit(10)
                        .collect(Collectors.toList());
                System.out.println(" "+ Explosions);
            }
            else if(ask == 4)
            {
                List<user> Ice_Quake = user1.stream()
                        .filter(e-> e.getType().equalsIgnoreCase("Ice Quake"))
                        .sorted(Comparator.comparingDouble(user::getMag).reversed())
                        .limit(10)
                        .collect(Collectors.toList());
                System.out.println(" "+ Ice_Quake);
            }
            else if(ask == 5)
            {
                List<user> Quarry_Blast = user1.stream()
                        .filter(e-> e.getType().equalsIgnoreCase("Quarry Blast"))
                        .sorted(Comparator.comparingDouble(user::getMag).reversed())
                        .limit(10)
                        .collect(Collectors.toList());
                System.out.println(" "+Quarry_Blast);
            }
            else {
                System.out.println("***wrong input***");
            }
            System.out.println("---------------------------------------------------------------------------------------------------------");
            System.out.println("***Chose one of the option**\n1 - To  Display the 10 Largest Earthquakes" +
                    "\n2 - To  Display the 10 nearest earthquakes to My location\n" +
                    "3 - To Display the 10 Largest Explosions\n" +
                    "4 - To Display the 10 Largest Ice Quake\n" +
                    "5 - To Display the 10 Largest Quarry Blast\n" +
                    "0 - to Exit");
            ask = sc.nextInt();
        }

    }
}
